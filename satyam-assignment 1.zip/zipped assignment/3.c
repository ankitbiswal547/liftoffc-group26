#include<stdio.h>
int main()
{
int r,dm;
printf("input the radius");
scanf("%d",&r);
dm=2*r;
printf("dm=%d\n",dm);
}
