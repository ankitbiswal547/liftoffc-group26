#include<stdio.h>
void main()
{
float cel,faren;
printf("input number in celcius");
scanf("%f",&cel);
faren=(cel*9/5)+32;
printf("faren=%f",faren);
}
